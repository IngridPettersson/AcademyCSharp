﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace IdentityDemo.Models.ViewModels
{
    public class AccountMembersVM
    {
        public string Username { get; set; }
    }
}
